export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { company } = req.body;
  if (!company) return res.status(400).json({ error: 'Campo company obrigatório' });

  const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
  if (!ANTHROPIC_API_KEY) return res.status(500).json({ error: 'API key não configurada' });

  const SYSTEM_PROMPT = `Você é um especialista em account intelligence para a ZapSign, plataforma líder de assinatura eletrônica no Brasil.
Pesquise a empresa na web e gere um briefing estratégico completo para preparação de reunião de vendas enterprise.
Retorne APENAS um JSON válido, sem markdown, sem backticks, sem texto antes ou depois:
{
  "company_name": "Nome oficial da empresa",
  "website": "site.com.br",
  "segment": "Segmento de atuação",
  "headquarters": "Cidade, Estado",
  "company_size": "Pequena / Média / Grande / Enterprise",
  "units": "Unidades/filiais estimadas",
  "employees": "Total de funcionários estimado",
  "annual_revenue": "Faturamento anual estimado",
  "executive_summary": "Resumo executivo em 3-4 parágrafos separados por \\n. Quem é a empresa, o que faz, momento atual, relevância para ZapSign.",
  "common_documents": ["Tipo 1","Tipo 2","Tipo 3","Tipo 4","Tipo 5","Tipo 6"],
  "pain_points": ["Dor 1","Dor 2","Dor 3","Dor 4","Dor 5"],
  "hypotheses": [
    {"hypothesis": "Hipótese 1","impact": "Impacto esperado"},
    {"hypothesis": "Hipótese 2","impact": "Impacto esperado"},
    {"hypothesis": "Hipótese 3","impact": "Impacto esperado"}
  ],
  "urgency_signals": ["Sinal 1","Sinal 2","Sinal 3","Sinal 4"],
  "discovery_questions": ["Pergunta 1?","Pergunta 2?","Pergunta 3?","Pergunta 4?","Pergunta 5?","Pergunta 6?","Pergunta 7?","Pergunta 8?"],
  "pitch_approach": "Linha de abordagem em 2-3 parágrafos separados por \\n.",
  "opening_line": "Frase de abertura para a reunião — direta, conecta dor ao valor da ZapSign."
}`;

  try {
    let messages = [
      { role: 'user', content: `Pesquise na web e gere o briefing estratégico completo para a empresa: "${company}"` }
    ];

    let finalData = null;

    for (let i = 0; i < 6; i++) {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01',
          'anthropic-beta': 'interleaved-thinking-2025-05-14'
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 2000,
          system: SYSTEM_PROMPT,
          tools: [{ type: 'web_search_20250305', name: 'web_search' }],
          messages
        })
      });

      if (!response.ok) {
        const err = await response.text();
        throw new Error(`Anthropic API error ${response.status}: ${err}`);
      }

      const data = await response.json();
      const toolUses = data.content.filter(b => b.type === 'tool_use');
      const textBlocks = data.content.filter(b => b.type === 'text' && b.text && b.text.trim().length > 20);

      if (!toolUses.length && textBlocks.length) {
        finalData = data;
        break;
      }

      if (toolUses.length) {
        messages.push({ role: 'assistant', content: data.content });
        const toolResults = toolUses.map(tu => ({
          type: 'tool_result',
          tool_use_id: tu.id,
          content: 'Resultados recebidos. Agora gere apenas o JSON do briefing.'
        }));
        messages.push({ role: 'user', content: toolResults });
      } else {
        finalData = data;
        break;
      }
    }

    if (!finalData) throw new Error('Sem resposta após loop de tool_use');

    const allText = finalData.content
      .filter(b => b.type === 'text')
      .map(b => b.text)
      .join('');

    let clean = allText.trim().replace(/```json|```/g, '').trim();
    const start = clean.indexOf('{');
    const end = clean.lastIndexOf('}') + 1;
    if (start === -1 || end === 0) throw new Error('JSON não encontrado na resposta');

    const parsed = JSON.parse(clean.slice(start, end));
    return res.status(200).json(parsed);

  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}
