# ZapSign · Briefing Estratégico

Site para geração automática de briefings de reunião para o time de vendas enterprise da ZapSign.

---

## Como colocar no ar (passo a passo)

### 1. Criar conta no GitHub
1. Acesse https://github.com e clique em **Sign up**
2. Crie sua conta (gratuita)
3. Após entrar, clique em **New repository** (botão verde)
4. Nome do repositório: `zapsign-briefing`
5. Deixe **Public** marcado
6. Clique em **Create repository**

### 2. Fazer upload dos arquivos
Na tela do repositório criado, clique em **uploading an existing file** e faça upload de todos os arquivos desta pasta mantendo a estrutura:
```
zapsign-briefing/
├── api/
│   └── briefing.js
├── public/
│   └── index.html
└── vercel.json
```

### 3. Criar conta na Vercel
1. Acesse https://vercel.com e clique em **Sign Up**
2. Escolha **Continue with GitHub** (conecta automaticamente)
3. Autorize o acesso

### 4. Fazer deploy
1. No dashboard da Vercel, clique em **Add New → Project**
2. Selecione o repositório `zapsign-briefing`
3. Clique em **Deploy** (sem mudar nada)
4. Aguarde ~1 minuto

### 5. Configurar a chave de API
1. No projeto na Vercel, vá em **Settings → Environment Variables**
2. Clique em **Add New**
3. Name: `ANTHROPIC_API_KEY`
4. Value: sua chave que começa com `sk-ant-...`
5. Clique em **Save**
6. Vá em **Deployments** e clique em **Redeploy** no deploy mais recente

### 6. Pronto!
Seu site estará disponível em uma URL como:
`https://zapsign-briefing.vercel.app`

Compartilhe esse link com o time de vendas.

---

## Onde obter a chave de API Anthropic
1. Acesse https://console.anthropic.com
2. Faça login ou crie uma conta
3. Vá em **API Keys → Create Key**
4. Copie a chave gerada

---

## Custo estimado
Cada briefing gerado consome ~$0,02 a $0,05 USD em tokens da API Anthropic.
Para 50 briefings/mês, o custo seria ~$1 a $2,50 USD/mês.
